var app = angular.module('app', []).config(function ($sceProvider) {//声明 angular
    $sceProvider.enabled(false);//使angular兼容ie7 BUG修复
});

/**
 * tools 相关
 * 15-4-14 */
var tools = {

    /**
     * angualr getJsp
     * 15-4-14 */
    getJsp: function ($http, getMoreUrl, re) {
        $http({method: 'JSONP', url: getMoreUrl + "?callback=JSON_CALLBACK"}).success(function (data) {
            re(data);
        }).error(function (data, status, headers, config) {
//            console.log("error");
        });
    },

    /**
     *判断空方法
     * 15-4-14 */
    isEmpty: function (t) {
        return $.trim(t) ? true : false;
    }

};
app.controller('body', function ($scope, $http) {

    /**
     *search 对象
     * 15-4-14 */
    $scope.search = {
        searchKey1: ''
    };

    /**
     * list 对象
     * 15-4-14 */
    $scope.list = {
        searchKey1: '',
        history: ''
    };

    /**
     * fun 对象
     * 15-4-14 */
    $scope.fun = {

        /**
         * search  点击事件
         * 15-4-14 */
        search: function (keyName) {
            var key = $scope.search[keyName];
            key = $.trim(key);
            if (!tools.isEmpty(key)) {
                alert('is not null');
                return false;
            } else {
                this.getSearchList(key, keyName);
            }
        },

        /**
         * 搜索记录查询
         * 15-4-15 */
        searchHistory: function (keyname) {
            this.mysqlSelect(keyname);
        },

        /**
         * 请求twitterApi
         * 15-4-14 */
        getSearchList: function (key, keyName) {
            var apiUrl = '/key/' + key + '/' + keyName;
            tools.getJsp($http, apiUrl, function (re) {
                if (re.data.statuses[0]) {
                    var endRe = re.data.statuses;
                    $scope.list[keyName] = endRe;

                    /**
                     * 将搜索结果入库
                     * 传入返回的data数据，搜索的关键词，搜索的分类“serchKey1,searchKey2”
                     * 15-4-14 */
                    $scope.fun.inMysql(endRe, key, keyName);
                } else {
                    $scope.list[keyName] = [{text: 'no search return!'}];
                }
            })
        },

        /**
         * 入库返回结果
         * 传入返回的data数据，搜索的关键词，搜索的分类“serchKey1,searchKey2”
         * 15-4-14 */
        inMysql: function (endRe, key, keyName) {
            /**
             * 组合post数据
             * 15-4-14 */
            var postData = {
                endRe: JSON.stringify(endRe),
                key: key,
                keyName: keyName,
                sqlType: 'add'
            };

            $.post('/postMysql', postData, function (re) {
                console.log('re', re);
            });
        },


        /**
         * 查询历史搜索记录
         * 15-4-15 */

        mysqlSelect: function (keyname) {
            /**
             * 组合post数据
             * 15-4-14 */
            var postData = {
                keyName: keyname,
                sqlType: 'select'
            };

            $.post('/postMysql', postData, function (re) {
                console.log('reselect', re);
                $scope.fun.showHistory(re);
            })
        },

        /**
         * 关闭historyDiv , 清空 history模型
         * 15-4-15 */
        closeHistory: function () {
            ui.hideGai();
            ui.hideHistory();
            $scope.list.history = '';
        },

        /**
         * 显示historyDiv，给list.history 数据
         * 15-4-15 */
        showHistory: function (data) {
            ui.showGai();
            ui.showHistory();
            setTimeout(function(){
                $scope.$apply(function(){
                    $scope.list.history = data;
                });
            },0)

        }

    };

    /**
     * ui fun
     * 15-4-15 */

    var ui = {
        showGai: function () {
            $('#gai').show();
        },
        hideGai: function () {
            $('#gai').hide();
        },
        showHistory: function () {
            $('#historyDiv').show();
        },
        hideHistory: function () {
            $('#historyDiv').hide();
        }
    }

})












