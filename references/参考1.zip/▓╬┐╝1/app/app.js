var express = require('express'); //express
var http = require('http');
var path = require('path');
var app = express();
var Twit = require('twit');//twitter
var mysql = require('mysql');//mysql
var connection = mysql.createConnection(
    {
        host: 'stusql.dcs.shef.ac.uk',
        port: '3306',
        user: 'acp14ym',
        password: 'ee8ba706',
        database: 'acp14ym'
    }
);

/**
 * 链接数据库
 * 15-4-14 */
connection.connect();

app.set('port', process.env.PORT || 3000);
app.set('views', path.join(__dirname, 'views'));//express 模板目录
app.set('view engine', 'jade');//express 模板引擎

app.use(express.static('public')); //express 静态目录
app.use(express.json());
app.use(express.urlencoded());
app.use(express.methodOverride());
app.use(express.cookieParser());
app.use(express.bodyParser());
http.createServer(app).listen(3000); //3000端口

/**
 * get url
 *
 * 15-4-14 */

app.get('/', function (req, res) {
    res.render('index');
});

/**
 * get 关键词请求方法，返回json
 * 15-4-14 */
app.get('/key/:key/:keyName', function (req, res) {

    /**
     * get key
     * 15-4-14 */
    var key = req.params.key;

    /**
     * get keyName 定制组合出前缀形容词，去设置不同的搜索关键词，返回不同结果
     * 如需扩展，直接 在 index.html 复制出searchDiv，改后面数字即可，这里，添加一个switch条件
     * 15-4-15 */

    var keyName = req.params.keyName;
    switch (keyName){
        case 'searchKey1':
            keyName = 'big';
            break;
        case 'searchKey2':
            keyName = 'small';
            break;
        default :
            keyName = '';
            break;
    }

     /**
     * 测试twitter token
     * 15-4-14 */
    var client = new Twit({
        consumer_key: '1MLcC0lgzX3RHxLOXfxdQt8GG',
        consumer_secret: 'YR7RwWnuXCRYjqcOGDUUkP7cl7blttQy1ae89gxnXMKdsqK3ju',
        access_token: '1412028176-o3H4VDTeFfysVhvDd7pRDv2DDvFdeSlLewwN6lp',
        access_token_secret: 'vgXR0nAEqNzPclCJQk494XwETL6f9FKWR8UXE2JYvyPPx'
    });



    client.get('search/tweets', {q:keyName +' '+ key, count: 10},
        function (err, data, response) {
            res.jsonp({data: data});
        });
});


app.post('/postMysql', function (req, res) {

    var sql = '';
    if (req.body.sqlType == 'add') {
        sql = "INSERT INTO `acp14ym`.`test1` (`id`, `json`, `key`, `searchkey`) VALUES (NULL," + Date.parse(new Date()) +
        " , \'" + req.body.key + "\', \'" + req.body.keyName + "\')";
    }

    if (req.body.sqlType == 'select') {
        sql = "SELECT * FROM  test1 WHERE searchkey = '"+ req.body.keyName +"' ORDER BY  `id` DESC LIMIT 0 , 30";
    }

    console.log('sql', sql);
    var query = connection.query(sql);

    query.on('error', function (err) {
        throw err;
    });

    query.on('fields', function (fields) {
        //console.log(fields);
    });

    var endRe = [];
    query.on('result', function (row) {
        endRe.push(row);
    });

    setTimeout(function(){
        //console.log('renRe',endRe);
        res.json(endRe);
    },800);

});

app.all('*', function (req, res) {
    res.redirect('/404.html');
});



