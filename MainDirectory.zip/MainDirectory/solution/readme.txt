To start the server, please enter: node app.js
Then in the browser’s address form input : localhost:3000/queryinterface
to start using the program


According to the requirement of 1.2a queries about specific users, the keywords must common to all users. Because there are a stoplist to token meanless words such as prepositions or conjunctions, there might be seldom data response. For testing this implement, you can empty or simplify the stoplist array in 2aQuery.